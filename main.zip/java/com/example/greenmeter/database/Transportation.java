package com.example.greenmeter.database;

public class Transportation {
    private String type_trans;
    private Double carbonEm;

    public void setType_trans(String type_trans) {
        this.type_trans = type_trans;
    }
    public void setCarbonEm(Double carbonEm) {
        this.carbonEm = carbonEm;
    }
}