package com.example.greenmeter;

/**
 * Mypage Main
 **/

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.firebase.auth.FirebaseAuth;

public class Mypage extends Fragment {
    private View view;
    private FirebaseAuth authService;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.mypage, container, false);
        authService = FirebaseAuth.getInstance();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();



        Button btn_logout = view.findViewById(R.id.logout_btn);
        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                authService.signOut();
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
                fragmentManager.beginTransaction().remove(Mypage.this).commit();
                fragmentManager.popBackStack();
            }
        });

        Button btn_delete_account = view.findViewById(R.id.delete_account_btn);
        btn_delete_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                authService.getCurrentUser().delete();
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
                fragmentManager.beginTransaction().remove(Mypage.this).commit();
                fragmentManager.popBackStack();
            }
        });
        return view;
    }

}
